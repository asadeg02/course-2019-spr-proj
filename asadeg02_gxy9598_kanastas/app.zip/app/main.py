import flask
from flask import Flask, Response, request, render_template, redirect, url_for
from sqlalchemy import create_engine
import json
from flask_pymongo import PyMongo
from collections import Counter
from werkzeug import secure_filename
import os, base64
from datetime import datetime, date
import scipy.stats
from sklearn import linear_model
from sklearn import preprocessing
import numpy as np


app = Flask(__name__)
#app.config["MONGO_URI"] = "mongodb://localhost:27017/finalproject"
#mongo = PyMongo(app)


with open('owner_value.json') as json_file:  
    data = json.load(json_file)

with open('people_data.json') as json_file:  
    data2 = json.load(json_file)


properties=[]


#Getting array of tuples (owner name, number of properties he owns)
def get_num_properties(data, properties):
	owners_addr = []
	for i in data:
		owners_addr.append((i['OWNER'], i['ADDRESS']))
	mylist = list(dict.fromkeys(owners_addr))
	#properties = Counter(elem[0] for elem in mylist)
	# for j in mylist:
	# 	properties.append((j[0], mylist.count(j[0])))
	d = {}
	for j in mylist:
		d[j[0]] = d.get(j[0], 0)+1
	return d.items()

owner_homes = get_num_properties(data, properties)


#Getting array of tuples (owner name, age)
def get_ages(data2):
	dates = []
	ages = []
	for i in data2:
		name = i['Last Name']+ ' '+ i['First Name'] + ' '+i['MI']
		dates.append((name,i['DOB']))
	for j in dates:
		date_birth = datetime.strptime(j[1], "%Y-%m-%d")
		today = date.today()
		age = today.year - date_birth.year - ((today.month, today.day) < (date_birth.month, date_birth.day))
		ages.append((j[0], age))
	return ages

owner_age = get_ages(data2)



#Concatenating two arrays above into array with tuples (owner, age, number of properties)
def concat_age_prop(owner_homes, owner_age):
	result = []
	for prop in owner_homes:
		for a in owner_age:
			if prop[0] == a[0]:
				result.append((prop[0],a[1],prop[1]))
	mylist = list(dict.fromkeys(result))
	d = {}
	for j in mylist:
		d[j[0]] = d.get(j[0], 0)+1
	return result

final = concat_age_prop(owner_homes, owner_age)

#Getting all ages in the range
def all_ages(low, high):
	ages = []
	range_num = int(high)-int(low)
	for i in range(range_num+1):
		if len(ages)>0:
			ages.append(ages[i-1])
		else:
			ages.append(low)
	return ages

#Getting ages in range
def ages_in_range(age_prop, low, high):
	result = []
	for x in age_prop:
		if x[1] >= int(low) and x[1] <= int(high):
			result.append((x[1], x[2]))
	return result

def get_total():
	return final








############################################################
#Communicating with html
############################################################

@app.route("/")
def home_page():
    #online_users = mongo.db.users.find({"online": True})
    return render_template("main.html")


#Finding and outputting regression analysis results
@app.route('/regression', methods=['GET', 'POST'])
def regression_output():
	return render_template("main.html")

@app.route('/doRegression', methods=['POST'])
def do_regression():
	low = request.form.get('low_range')
	high = request.form.get('high_range')
	total_ages = all_ages(low, high)
	ages_prop_range = ages_in_range(get_total(), low, high)

	a = [age1 for (age1, num_prop1) in ages_prop_range]
	n = [num_prop2 for (age2, num_prop2) in ages_prop_range] 
	
	a_train = np.array(a)
	n_train = np.array(n)


	min_max_scaler = preprocessing.MinMaxScaler()
	#Normalizing training data using min max scaler 
	a_train = min_max_scaler.fit_transform(a_train.reshape(-1,1))
	n_train = min_max_scaler.fit_transform(n_train.reshape(-1,1))  
	regr = linear_model.LinearRegression()
	regr.fit(a_train,n_train)
	regression_result = regr.coef_[0][0]
	print(regression_result)
	return render_template('main.html', messageR = str(regression_result))



#Finding and outputting correlation analysis results
@app.route('/correlation', methods=['GET', 'POST'])
def correlation_output():
	return render_template("correlation.html")

@app.route('/doCorrelation', methods=['POST'])
def do_correlation():
	low = request.form.get('low_range')
	high = request.form.get('high_range')
	total_ages = all_ages(low, high)
	ages_prop_range = ages_in_range(get_total(), low, high)

	a = [age1 for (age1, num_prop1) in ages_prop_range]
	n = [num_prop2 for (age2, num_prop2) in ages_prop_range] 
	corr = scipy.stats.pearsonr(a, n)
	print(corr)
	return render_template('main.html', messageC = str(corr[0]))











